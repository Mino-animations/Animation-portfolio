import data from "./Data";

document.title = data.WebsiteTitle;
