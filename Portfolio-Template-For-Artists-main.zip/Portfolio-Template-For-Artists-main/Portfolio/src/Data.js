const Data = {
  WebsiteTitle: "Portfolio | Artists",
  HeaderTitle: "Artist's Portfolio",
  FooterText: "© 2024 Artist's Portfolio. All rights reserved.",
  AboutEmail: "Your Email Address",
  AboutEmailSubject: "Subject of the Email",
  AboutHeading: "About Me",
  AboutTextParagraph1:
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
  AboutTextParagraph2:
    " Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
  AboutButtonText: "Say Hey!",
};

export default Data;
